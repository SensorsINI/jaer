/*
 * Copyright (C) 2013 Klaus Reimer <k@ailis.de>
 * See LICENSE.md for licensing information.
 */

/**
 * Low-Level classes based on the native libusb library.
 */
package org.usb4java;

