/**
 * Contains all the annotation classes used by JavaCPP.
 */
package org.bytedeco.javacpp.annotation;
